﻿using RobotService.Models.Contracts;
using RobotService.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotService.Repositories
{
    public class SupplementRepository : IRepository<ISupplement>
    {
        private List<ISupplement> supplementRepository;
        public SupplementRepository()
        {
            supplementRepository = new List<ISupplement>();
        }
        public void AddNew(ISupplement model)
        {
            supplementRepository.Add(model);
        }

        public ISupplement FindByStandard(int interfaceStandard)
        {
            var standart = supplementRepository.FirstOrDefault(a => a.InterfaceStandard == interfaceStandard);
            return standart;
        }

        public IReadOnlyCollection<ISupplement> Models() =>supplementRepository.AsReadOnly();
        

        public bool RemoveByName(string typeName)
        {
            var element = supplementRepository.FirstOrDefault(a => a.GetType().Name == typeName);
            if (element != null)
            {
                supplementRepository.Remove(element);
                return true;
            }
            else return false;
        }
    }
}
