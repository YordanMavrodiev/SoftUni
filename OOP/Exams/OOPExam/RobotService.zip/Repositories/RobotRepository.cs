﻿using RobotService.Models.Contracts;
using RobotService.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotService.Repositories
{
    public class RobotRepository : IRepository<IRobot>
    {
        private List<IRobot> robotRepository;
        public RobotRepository()
        {
            robotRepository = new List<IRobot>();
        }
        public void AddNew(IRobot robot)
        {
            robotRepository.Add(robot);
        }

        public IRobot FindByStandard(int interfaceStandard)
        {
            var standart = robotRepository.FirstOrDefault(a => a.InterfaceStandards.Any(ae => ae == interfaceStandard));
            return standart;
        }

        public IReadOnlyCollection<IRobot> Models() => robotRepository.AsReadOnly();


        public bool RemoveByName(string robotModel)
        {
            var element = robotRepository.FirstOrDefault(a => a.GetType().Name == robotModel);
            if (element != null)
            {
                robotRepository.Remove(element);
                return true;
            }
            else return false;
        }
    }
}
